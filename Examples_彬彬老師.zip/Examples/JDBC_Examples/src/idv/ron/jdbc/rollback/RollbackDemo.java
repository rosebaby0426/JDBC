package idv.ron.jdbc.rollback;

import static idv.ron.jdbc.dml.Common.PASSWORD;
import static idv.ron.jdbc.dml.Common.URL;
import static idv.ron.jdbc.dml.Common.USER;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RollbackDemo {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		String sql = "INSERT INTO BOOK "
				+ "(ISBN, BOOK_NAME, PRICE, AUTHOR, PUBLICATION_DATE, PUBLISHER_ID) "
				+ "VALUES(?, ?, ?, ?, ?, ?)";
		try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
				PreparedStatement ps = connection.prepareStatement(sql);) {
			connection.setAutoCommit(false);
			double price = 500;
			ps.setString(1, "0123456789");
			ps.setString(2, "Android App");
			ps.setDouble(3, price);
			ps.setString(4, "Allen");
			ps.setString(5, "2018-6-1");
			ps.setString(6, "P001");
			int rowCount = ps.executeUpdate();
			if (price >= 600) {
				connection.rollback();
				System.out.println("Inserting is rolled back!!");
			} else {
				System.out.println(rowCount + " row(s) inserted!!");
			}
			connection.commit();
			connection.setAutoCommit(true);
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
}