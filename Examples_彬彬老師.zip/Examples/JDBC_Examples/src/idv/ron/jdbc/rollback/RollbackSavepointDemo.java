package idv.ron.jdbc.rollback;

import static idv.ron.jdbc.dml.Common.PASSWORD;
import static idv.ron.jdbc.dml.Common.URL;
import static idv.ron.jdbc.dml.Common.USER;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;

public class RollbackSavepointDemo {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		String sql = "INSERT INTO BOOK " + 
					 "(ISBN, BOOK_NAME, PRICE, AUTHOR, PUBLICATION_DATE, PUBLISHER_ID) " + 
					 "VALUES(?, ?, ?, ?, ?, ?)";
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
			connection.setAutoCommit(false);
			Savepoint savepoint1 = connection.setSavepoint();
			ps = connection.prepareStatement(sql);
			ps.setString(1, "1111111111");
			ps.setString(2, "AAA");
			ps.setDouble(3, 550);
			ps.setString(4, "Allen");
			ps.setString(5, "2018-6-1");
			ps.setString(6, "P001");
			ps.executeUpdate();

			Savepoint savepoint2 = connection.setSavepoint();
			ps.setString(1, "2222222222");
			ps.setString(2, "BBB");
			ps.setDouble(3, 600);
			ps.setString(4, "Ivy");
			ps.setString(5, "2018-8-1");
			ps.setString(6, "P001");
			ps.executeUpdate();

			connection.rollback(savepoint2);
			System.out.println("Savepoint2 is rolled back!!");

			connection.commit();
			connection.setAutoCommit(true);
		} catch (SQLException e) {
			System.out.println(e);
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}