package idv.ron.jdbc.rollback;

import static idv.ron.jdbc.dml.Common.PASSWORD;
import static idv.ron.jdbc.dml.Common.URL;
import static idv.ron.jdbc.dml.Common.USER;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RollbackErrorDemo {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		String sql = "INSERT INTO BOOK "
				+ "(ISBN, BOOK_NAME, PRICE, AUTHOR, PUBLICATION_DATE, PUBLISHER_ID) "
				+ "VALUES (?, ?, ?, ?, ?, ?)";
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = DriverManager.getConnection(URL, USER, PASSWORD);
			ps = connection.prepareStatement(sql);
			connection.setAutoCommit(false);
			double price = 500;
			ps.setString(1, "0123456789");
			ps.setString(2, "Android App");
			ps.setDouble(3, price);
			ps.setString(4, "Allen");
			ps.setString(5, "2018-6-1");
			ps.setString(6, "P001");
			int rowCount = ps.executeUpdate();
			System.out.println(rowCount + " row(s) inserted!!");
			connection.commit();
		} catch (SQLException e) {
			try {
				connection.rollback();
				System.err.println("Inserting is rolled back because of "
						+ e.getMessage());
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}