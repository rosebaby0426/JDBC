﻿package idv.ron.jdbc.dml;

import static idv.ron.jdbc.dml.Common.PASSWORD;
import static idv.ron.jdbc.dml.Common.URL;
import static idv.ron.jdbc.dml.Common.USER;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

class ConnectTestDemo {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);) {
			System.out.println("connecting to the database successfully!!");
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
}