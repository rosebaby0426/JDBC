﻿package idv.ron.jdbc.dml;

import static idv.ron.jdbc.dml.Common.PASSWORD;
import static idv.ron.jdbc.dml.Common.URL;
import static idv.ron.jdbc.dml.Common.USER;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

class SelectDemo {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		ResultSetMetaData metaData;
		int columnCount = 0;
		int rowCount = 0;
		String sql = "SELECT BOOK_NAME, PRICE FROM BOOK WHERE BOOK_NAME LIKE ?";
		try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
				PreparedStatement ps = connection.prepareStatement(sql);) {
			ps.setString(1, "%Java%");
			metaData = ps.getMetaData();
			columnCount = metaData.getColumnCount();
			for (int i = 1; i <= columnCount; i++)
				System.out.print(metaData.getColumnName(i) + "\t\t\t");
			System.out.println();
			try (ResultSet rs = ps.executeQuery();) {
				while (rs.next()) {
					for (int i = 1; i <= columnCount; i++)
						System.out.print(rs.getObject(i) + "\t");
					System.out.println();
				}
				rs.last();
				rowCount = rs.getRow();
			}
			System.out.println("-----total " + rowCount + " row(s)-----");
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
}