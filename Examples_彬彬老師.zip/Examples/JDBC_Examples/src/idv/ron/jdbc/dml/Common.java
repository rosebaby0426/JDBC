package idv.ron.jdbc.dml;

public class Common {
	public final static String URL = "jdbc:mysql://localhost:3306/Bookshop";
	public final static String USER = "root";
	public final static String PASSWORD = "root";
}
