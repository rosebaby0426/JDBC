package idv.ron.jdbc.dml;

import static idv.ron.jdbc.dml.Common.PASSWORD;
import static idv.ron.jdbc.dml.Common.URL;
import static idv.ron.jdbc.dml.Common.USER;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

class SelectGenKeyDemo {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		String sql = "INSERT INTO EMPLOYEE (EMPLOYEE_NAME) VALUES (?)";
		try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
				PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {
			ps.setString(1, "Mary");
			int rowCount = ps.executeUpdate();
			// TimeStamp column is not a auto-generated key
			ResultSet rs = ps.getGeneratedKeys();

			if (rs.next()) {
				int employee_id = rs.getInt(1);
				System.out.println(rowCount + " row inserted; Employee ID: " + employee_id);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
}