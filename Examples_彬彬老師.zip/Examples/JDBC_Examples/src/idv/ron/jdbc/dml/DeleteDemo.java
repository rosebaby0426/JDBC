﻿package idv.ron.jdbc.dml;

import static idv.ron.jdbc.dml.Common.PASSWORD;
import static idv.ron.jdbc.dml.Common.URL;
import static idv.ron.jdbc.dml.Common.USER;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

class DeleteDemo {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		String sql = "DELETE FROM PUBLISHER WHERE PUBLISHER_ID = ?";
		try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
				PreparedStatement ps = connection.prepareStatement(sql);) {
			ps.setString(1, "P00Z");
			int rowCount = ps.executeUpdate();
			System.out.println(rowCount + " row(s) deleted!!");
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
}