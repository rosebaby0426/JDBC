-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 23, 2018 at 02:13 PM
-- Server version: 5.6.38
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Bookshop`
--
CREATE DATABASE IF NOT EXISTS `Bookshop` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `Bookshop`;

-- --------------------------------------------------------

--
-- Table structure for table `BOOK`
--

DROP TABLE IF EXISTS `BOOK`;
CREATE TABLE IF NOT EXISTS `BOOK` (
  `ISBN` char(13) NOT NULL,
  `BOOK_NAME` varchar(200) NOT NULL,
  `PRICE` decimal(8,2) DEFAULT NULL,
  `AUTHOR` varchar(200) DEFAULT NULL,
  `PUBLICATION_DATE` date DEFAULT NULL,
  `PUBLISHER_ID` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`ISBN`),
  KEY `FK_BOOK_PUBLISHER` (`PUBLISHER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `BOOK`
--

INSERT INTO `BOOK` (`ISBN`, `BOOK_NAME`, `PRICE`, `AUTHOR`, `PUBLICATION_DATE`, `PUBLISHER_ID`) VALUES
('9780071751292', 'Oracle Database 11g', '1139.00', 'Jinyu Wang', '2011-09-14', 'P005'),
('9780134543666', 'Starting Out with Python', '5451.00', 'Tony Gaddis', '2017-06-15', 'P006'),
('9780596009205', 'Head First Java', '1186.00', 'Kathy Sierra and Bert Bates', '2005-02-19', 'P001'),
('9780596809157', 'R Cookbook', '935.00', 'Paul Teetor', '2016-03-01', 'P001'),
('9781118407813', 'Beginning Programming with Java For Dummies', '550.00', 'Barry Burd', '2014-07-11', 'P002'),
('9781259587405', 'Programming the Raspberry Pi', '440.00', 'Simon Monk', '2015-10-05', 'P005'),
('9781430237174', 'Pro IOS Apps Performance Optimization', '1151.00', 'Khang Vo', '2011-11-16', 'P004'),
('9781484226766', 'Python Unit Test Automation', '731.00', 'Ashwin Pajankar', '2017-06-12', 'P004'),
('9781491936696', 'iOS 9 Swift Programming Cookbook', '1443.00', 'Vandad Nahavandipoor', '2016-01-08', 'P001'),
('9781617291999', 'Java 8 in Action', '936.00', 'Raoul-gabriel Urma, Mario Fusco, Alan Mycroft', '2014-08-28', 'P003');

-- --------------------------------------------------------

--
-- Table structure for table `EMPLOYEE`
--

DROP TABLE IF EXISTS `EMPLOYEE`;
CREATE TABLE IF NOT EXISTS `EMPLOYEE` (
  `EMPLOYEE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMPLOYEE_NAME` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`EMPLOYEE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `PUBLISHER`
--

DROP TABLE IF EXISTS `PUBLISHER`;
CREATE TABLE IF NOT EXISTS `PUBLISHER` (
  `PUBLISHER_ID` varchar(40) NOT NULL,
  `PUBLISHER_NAME` varchar(40) NOT NULL,
  `CONTACT` varchar(40) DEFAULT NULL,
  `PHONE` varchar(40) NOT NULL,
  `TIMESTAMP` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`PUBLISHER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PUBLISHER`
--

INSERT INTO `PUBLISHER` (`PUBLISHER_ID`, `PUBLISHER_NAME`, `CONTACT`, `PHONE`, `TIMESTAMP`) VALUES
('P001', 'O\'Reilly', 'Ocean', '02-23456789', '2018-06-22 06:24:50'),
('P002', 'John Wiley, Sons Inc', 'Don', '03-36962869', '2018-06-22 06:24:50'),
('P003', 'Manning Publications', 'Mary', '04-43456789', '2018-06-22 06:24:50'),
('P004', 'Apress', 'Allen', '05-59876543', '2018-06-22 06:24:50'),
('P005', 'McGraw-Hill', 'Mike', '06-69876543', '2018-06-22 06:24:50'),
('P006', 'Pearson', 'Paul', '09-98767867', '2018-06-22 06:24:50'),
('P00X', 'Publisher X', 'X-Man', '07-75698765', '2018-06-22 06:24:50'),
('P00Y', 'Publisher Y', 'Yale', '08-83698765', '2018-06-22 06:24:50');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `BOOK`
--
ALTER TABLE `BOOK`
  ADD CONSTRAINT `FK_BOOK_PUBLISHER` FOREIGN KEY (`PUBLISHER_ID`) REFERENCES `PUBLISHER` (`PUBLISHER_ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
